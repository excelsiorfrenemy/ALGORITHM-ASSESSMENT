#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "PES1UG19CS235_H.h"

void DijktraAlgo(int start,adjnode* AdjList[],int nv,heapnode* output[])
{
	adjnode*current=AdjList[start];
	int i,sum=0;
	int prev=start;
	int heapsize=0;
	heapnode*new=NULL;
	int* visited=malloc((nv+1)*sizeof(int));
	for(i=0;i<nv+1;i++)
		visited[i]=0;
	heapnode* heap[1000];
	for(i=0;i<1000;i++)
		heap[i]=NULL;
	visited[start]=1;
	do
	{
		while(current!=NULL)
		{
			++heapsize;
			heap_insert(current,prev,heap,heapsize,sum);
			current=current->next;
		}
		new=heappull(heap,heapsize);
		--heapsize;
		while(new!=NULL && visited[new->v_id])
		{
			free(new);
			new=heappull(heap,heapsize);
			--heapsize;
		}
		if(new==NULL)
			break;
		visited[new->v_id]=1;
		current=AdjList[new->v_id];
		prev=new->v_id;
		sum=new->dist;
		output[new->v_id]=new;
	}while(1);
	free(visited);
}

void heap_insert(adjnode* curr,int prev,heapnode* heap[],int n,int sum)
{
	heapnode* node=(heapnode*)malloc(sizeof(heapnode));
	node->v_id=curr->v_id;
	node->prev=prev;
	node->dist=(curr->weight)+sum;
	heap[n - 1] = node;
	heapifyinsert(heap,n, n - 1);
}

void heapifyinsert(heapnode* heap[], int n, int i)
{
	int parent = (i - 1) / 2;
	heapnode* temp;
	if (heap[parent] > 0)
	{
		if (heap[i]->dist < heap[parent]->dist)
		{
			temp=heap[i];
			heap[i]=heap[parent];
			heap[parent]=temp;
			heapifyinsert(heap,n,parent);
		}
	}
}

heapnode* heappull(heapnode* heap[], int n)
{
	heapnode* temp=heap[0];
	if(n==0)
	{
		return NULL;
	}
	heapnode* lastElement = heap[n - 1];
	heap[0] = lastElement;
	heapifydelete(heap, n, 0);
	return temp;
}

void heapifydelete(heapnode* heap[], int n, int i)
{
	heapnode* temp;
	int smallest = i;
	int l = 2 * i + 1;
	int r = 2 * i + 2;
	if (l < n && (heap[l]->dist < heap[smallest]->dist))
		smallest = l;
	if (r < n && (heap[r]->dist < heap[smallest]->dist))
		smallest = r;
	if (smallest != i) {
		temp=heap[i];
		heap[i]=heap[smallest];
		heap[smallest]=temp;
		heapifydelete(heap, n, smallest);
	}
}

