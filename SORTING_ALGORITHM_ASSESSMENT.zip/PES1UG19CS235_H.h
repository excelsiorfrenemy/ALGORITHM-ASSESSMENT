#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct adjNode
{
	int weight;
	int v_id;
	struct adjNode* next;
}adjnode;

typedef struct heapNode
{
	int v_id;
	int prev;
	int dist;
}heapnode;

void DijktraAlgo(int,adjnode**,int,heapnode**);
void heap_insert(adjnode*,int,heapnode*[],int,int);
void heapifyinsert(heapnode*[], int, int);
heapnode* heappull(heapnode*[], int);
void heapifydelete(heapnode* [], int, int);
