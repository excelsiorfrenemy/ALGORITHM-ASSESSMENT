#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "PES1UG19CS235_H.h"

int main()
{
	FILE*fp;
	char NoOfVertex[10];
	char* token,* temp;
	char n[2]="\n";
	int i=0,nv=0,linelim=10,tokenindex=0;
	char space[2]=" ";
	adjnode*current=NULL;
	adjnode*prev=NULL;
	fp=fopen("adjacencylist.txt","r");
	fgets(NoOfVertex,10,fp);
	nv=atoi(NoOfVertex);
	adjnode* indexarray[nv+1];
	heapnode* output[nv+1];

	for(i=0;i<nv+1;i++)
	{
		output[i]=NULL;
		indexarray[i]=NULL;
	}

	linelim=100000;
	char line[linelim];

	for(i=0;i<nv;i++)
	{
		fgets(line,linelim,fp);
		token=strtok(line,space);
		tokenindex=atoi(token);

		while(token != NULL)
		{
			temp = strtok(NULL, space);
			if (temp==NULL || temp==n)
				break;
			current=(adjnode*)malloc(sizeof(adjnode));
			if(current==NULL)
				exit(0);
			current->v_id=tokenindex;
			token = strtok(NULL, space);
			current->weight=atoi(token);
			current->next=indexarray[atoi(temp)];
			indexarray[atoi(temp)]=current;
		}
	}
	fclose(fp);
	DijktraAlgo(nv,indexarray,nv,output);
	heapnode* tempx;

	for(i=1;i<nv;i++)
	{
		if(output[i]==NULL)
		{
			printf("NO PATH\n");
			continue;
		}
		tempx=output[i];
		printf("%d %d ",i,tempx->v_id);

		while((tempx->prev)!=nv)
		{
			tempx=output[tempx->prev];
			printf("%d ",tempx->v_id);
		}
		printf("%d %d\n",nv,output[i]->dist);
	}

	for(i=1;i<nv+1;i++)
	{
		free(output[i]);
		current=indexarray[i];
		prev=current;

		while(current!=NULL)
		{
			current=current->next;
			free(prev);
			prev=current;
		}
		indexarray[i]=NULL;
	}
}
